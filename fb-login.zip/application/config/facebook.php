<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['appID']	= '597407837087263';


$config['appSecret']	= '21a8846148a850729842aada24cd9c87';


/* End of file facebook.php */
/* Location: ./application/config/facebook.php */
